module.exports = {
	env: 1,
	script_breakdown_server_ip_prod: 'http://script-breakdown.us-east-2.elasticbeanstalk.com/' // Prod
}
