export { default as confirmUserMiddleware } from "./confirmUser.middleware";
